import os
import logging
from datetime import datetime, timezone
from typing import Optional
import requests
from .models import EmbedTokenRequest, EmbedTokenResponse

# Acquire Power BI access token using client credentials

def acquire_access_token() -> Optional[str]:
    tenant_id = os.getenv('PBI_TENANT_ID')
    client_id = os.getenv('PBI_CLIENT_ID')
    client_secret = os.getenv('PBI_CLIENT_SECRET')
    if not all([tenant_id, client_id, client_secret]):
        logging.warning('Power BI service principal credentials not fully configured')
        return None
    token_url = f'https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token'
    data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'https://analysis.windows.net/powerbi/api/.default',
        'grant_type': 'client_credentials'
    }
    try:
        resp = requests.post(token_url, data=data, timeout=30)
        if resp.status_code != 200:
            logging.error('Failed to get Power BI token: %s %s', resp.status_code, resp.text)
            return None
        return resp.json().get('access_token')
    except Exception:  # pragma: no cover
        logging.exception('Failed to acquire Power BI access token')
        return None


def generate_embed_token(pbi_access_token: str, request: EmbedTokenRequest) -> EmbedTokenResponse:
    try:
        headers = {'Authorization': f'Bearer {pbi_access_token}', 'Content-Type': 'application/json'}
        # Validate report retrieval
        report_url = f'https://api.powerbi.com/v1.0/myorg/groups/{request.workspace_id}/reports/{request.report_id}'
        report_resp = requests.get(report_url, headers=headers, timeout=30)
        if report_resp.status_code != 200:
            return EmbedTokenResponse(embed_token=None, expiration=None, error=f'Report fetch failed: {report_resp.status_code} {report_resp.text}', report_id=request.report_id, workspace_id=request.workspace_id)
        report_data = report_resp.json()
        dataset_id = report_data.get('datasetId')
        if not dataset_id:
            return EmbedTokenResponse(embed_token=None, expiration=None, error='DatasetId missing in report metadata', report_id=request.report_id, workspace_id=request.workspace_id)

        gen_url = 'https://api.powerbi.com/v1.0/myorg/GenerateToken'
        payload = {
            'reports': [{'id': request.report_id, 'allowEdit': False}],
            'datasets': [{'id': dataset_id}],
            'targetWorkspaces': [{'id': request.workspace_id}]
        }
        gen_resp = requests.post(gen_url, headers=headers, json=payload, timeout=30)
        if gen_resp.status_code != 200:
            return EmbedTokenResponse(embed_token=None, expiration=None, error=f'Generate token failed: {gen_resp.status_code} {gen_resp.text}', report_id=request.report_id, workspace_id=request.workspace_id)
        gen_json = gen_resp.json()
        token = gen_json.get('token')
        exp_str = gen_json.get('expiration')
        expiration = None
        if exp_str:
            try:
                expiration = datetime.fromisoformat(exp_str.replace('Z', '+00:00')).astimezone(timezone.utc)
            except Exception:  # pragma: no cover
                pass
        return EmbedTokenResponse(embed_token=token, expiration=expiration, error=None, report_id=request.report_id, workspace_id=request.workspace_id)
    except Exception as ex:  # pragma: no cover
        logging.exception('Failed to generate embed token')
        return EmbedTokenResponse(embed_token=None, expiration=None, error=str(ex), report_id=request.report_id, workspace_id=request.workspace_id)
