from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import json
from typing import List, Optional, Any, Dict

@dataclass
class EmbedTokenRequest:
    workspace_id: str
    report_id: str
    username: str
    groups: List[str]
    user_location: str

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'EmbedTokenRequest':
        try:
            return EmbedTokenRequest(
                workspace_id=data.get('workspaceId') or data.get('WorkspaceId') or '',
                report_id=data.get('reportId') or data.get('ReportId') or '',
                username=data.get('username') or data.get('Username') or '',
                groups=list(data.get('groups') or data.get('Groups') or []),
                user_location=data.get('userLocation') or data.get('UserLocation') or ''
            )
        except Exception as e:  # pragma: no cover
            raise ValueError(f'Invalid request: {e}')

@dataclass
class EmbedTokenResponse:
    embed_token: Optional[str]
    expiration: Optional[datetime]
    error: Optional[str]
    report_id: Optional[str] = None
    workspace_id: Optional[str] = None

    def to_json(self) -> str:
        def default(o):
            if isinstance(o, datetime):
                return o.isoformat()
            return o
        return json.dumps({
            'embedToken': self.embed_token,
            'expiration': self.expiration.isoformat() if self.expiration else None,
            'error': self.error,
            'reportId': self.report_id,
            'workspaceId': self.workspace_id
        }, default=default)
