import os
import logging
from azure.storage.blob import BlobServiceClient


def is_authorized(username: str, location: str) -> bool:
    try:
        conn = os.getenv('AzureWebJobsStorage')
        if not conn:
            logging.warning('AzureWebJobsStorage not configured')
            return False
        container = os.getenv('USER_CSV_CONTAINER', 'data')
        filename = os.getenv('USER_CSV_FILENAME', 'user_locations.csv')
        service = BlobServiceClient.from_connection_string(conn)
        blob_client = service.get_blob_client(container=container, blob=filename)
        if not blob_client.exists():
            logging.warning('User CSV blob not found: %s', filename)
            return False
        data = blob_client.download_blob().content_as_text(encoding='utf-8')
        for line in data.splitlines():
            if not line.strip():
                continue
            parts = [p.strip() for p in line.split(',') if p.strip()]
            if len(parts) < 2:
                continue
            if parts[0].lower() == username.lower() and parts[1].lower() == location.lower():
                return True
        return False
    except Exception:  # pragma: no cover - log and deny
        logging.exception('Error validating user authorization')
        return False
