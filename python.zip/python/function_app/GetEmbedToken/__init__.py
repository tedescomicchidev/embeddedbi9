import json
import logging
import os
import azure.functions as func
from datetime import datetime, timezone
from .pbi import acquire_access_token, generate_embed_token
from .models import EmbedTokenRequest, EmbedTokenResponse
from .authz import is_authorized

JSON_CT = 'application/json'


def main(req: func.HttpRequest) -> func.HttpResponse:  # type: ignore
    logging.info("GetEmbedToken Python function processed a request.")
    try:
        if not req.get_body():
            return _bad_request("Empty body")
        try:
            payload = req.get_json()
        except ValueError:
            return _bad_request("Invalid JSON")
        try:
            request = EmbedTokenRequest.from_dict(payload)
        except ValueError as e:
            return _bad_request(str(e))

        missing = [name for name, value in [
            ("WorkspaceId", request.workspace_id),
            ("ReportId", request.report_id),
            ("Username", request.username),
            ("UserLocation", request.user_location),
        ] if not value]
        if missing:
            return _bad_request(f"Missing required fields: {', '.join(missing)}")

        # Authorization via blob CSV
        if not is_authorized(request.username, request.user_location):
            resp = EmbedTokenResponse(embed_token=None, expiration=None, error="User and location not authorized", report_id=request.report_id, workspace_id=request.workspace_id)
            return func.HttpResponse(resp.to_json(), status_code=403, mimetype=JSON_CT)

        pbi_token = acquire_access_token()
        if not pbi_token:
            resp = EmbedTokenResponse(embed_token=None, expiration=None, error="Failed to acquire Power BI access token", report_id=request.report_id, workspace_id=request.workspace_id)
            return func.HttpResponse(resp.to_json(), status_code=500, mimetype=JSON_CT)

        embed_resp = generate_embed_token(pbi_token, request)
        if not embed_resp.embed_token:
            return func.HttpResponse(embed_resp.to_json(), status_code=500, mimetype=JSON_CT)
        return func.HttpResponse(embed_resp.to_json(), status_code=200, mimetype=JSON_CT)
    except Exception as ex:  # pylint: disable=broad-except
        logging.exception("Error generating embed token")
        resp = EmbedTokenResponse(embed_token=None, expiration=None, error=str(ex))
        return func.HttpResponse(resp.to_json(), status_code=500, mimetype=JSON_CT)


def _bad_request(msg: str) -> func.HttpResponse:
    resp = EmbedTokenResponse(embed_token=None, expiration=None, error=msg)
    return func.HttpResponse(resp.to_json(), status_code=400, mimetype=JSON_CT)
