# Python Translation of .NET Embed Demo

This directory contains Python equivalents of the original .NET solutions:

- `function_app/` - Azure Function (HTTP Trigger) providing `/api/generateEmbedToken` identical to C# Function.
- `web_app/` - Flask web application replicating the MVC app UI and `/EmbedToken` proxy endpoint.

## Structure

```
python/
  function_app/
    GetEmbedToken/
      __init__.py
      function.json
      models.py
      authz.py
      pbi.py
    host.json
    local.settings.json
  web_app/
    __init__.py (Flask app)
    templates/
      home/index.html
      home/privacy.html
  requirements.txt
```

## Environment Variables

Function App expects (like original .NET):
- `PBI_CLIENT_ID`
- `PBI_CLIENT_SECRET`
- `PBI_TENANT_ID`
- `AzureWebJobsStorage` (connection string) or `UseDevelopmentStorage=true` for Azurite
- `USER_CSV_CONTAINER` (default `data`)
- `USER_CSV_FILENAME` (default `user_locations.csv`)

Flask App additional:
- `FUNCTION_API_BASE_URL` (default `http://localhost:7071`)
- `DEMO_USERNAME` (placeholder until OIDC added)

## Running Locally

Install deps:
```
pip install -r python/requirements.txt
```

Start Azure Function (from repository root):
```
cd python/function_app
func start
```

Start Flask app (separate shell):
```
export FUNCTION_API_BASE_URL=http://localhost:7071
python -m flask --app python/web_app run --port 5000 --reload
```

Browse to http://localhost:5000

## Notes

- Authentication (OIDC) from .NET MVC not yet ported; can be added with `msal` or `flask-azure-oauth`.
- Power BI REST calls implemented with raw `requests` similar to .NET SDK usage.
- CSV authorization logic mirrors original behavior.
