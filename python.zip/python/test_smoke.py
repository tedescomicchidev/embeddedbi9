import os
import json
import requests

FUNCTION_URL = os.getenv('FUNCTION_URL', 'http://localhost:7071/api/generateEmbedToken')

sample_body = {
    'workspaceId': '00000000-0000-0000-0000-000000000000',
    'reportId': '00000000-0000-0000-0000-000000000000',
    'username': 'demo@example.com',
    'groups': [],
    'userLocation': 'US'
}

def main():
    try:
        r = requests.post(FUNCTION_URL, json=sample_body, timeout=10)
        print('Status:', r.status_code)
        print('Body:', r.text[:500])
    except Exception as e:
        print('Error', e)

if __name__ == '__main__':
    main()
