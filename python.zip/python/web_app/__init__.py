from flask import Flask, render_template, request, jsonify
import os
import requests

# NOTE: Authentication (OIDC) in .NET app is not replicated here.
# For parity demonstration, routes assume user is already authenticated.
# You can integrate msal or azure-ad authentication later if needed.


def create_app():
    app = Flask(__name__)
    app.config['FUNCTION_API_BASE_URL'] = os.getenv('FUNCTION_API_BASE_URL', 'http://localhost:7071')

    @app.route('/')
    def index():
        return render_template('home/index.html')

    @app.route('/Privacy')
    def privacy():
        return render_template('home/privacy.html')

    @app.post('/EmbedToken')
    def embed_token():
        data = request.get_json(force=True, silent=True) or {}
        workspace_id = data.get('workspaceId')
        report_id = data.get('reportId')
        user_location = data.get('userLocation')
        # In .NET version username/groups are derived from claims.
        # Here we emulate with environment or placeholder.
        username = os.getenv('DEMO_USERNAME', 'unknown')
        groups = []
        if not all([workspace_id, report_id, user_location]):
            return jsonify({ 'error': 'Missing required fields'}), 400
        payload = {
            'workspaceId': workspace_id,
            'reportId': report_id,
            'username': username,
            'groups': groups,
            'userLocation': user_location
        }
        base = app.config['FUNCTION_API_BASE_URL'].rstrip('/')
        url = f"{base}/api/generateEmbedToken"
        try:
            resp = requests.post(url, json=payload, timeout=60)
            try:
                body = resp.json()
            except Exception:
                body = {'error': f'Non-JSON response: {resp.text[:200]}'}
            if not resp.ok or body.get('error'):
                return jsonify({ 'error': body.get('error') or f'Function error {resp.status_code}' }), 500
            return jsonify(body)
        except requests.exceptions.SSLError as ssl_ex:
            # Attempt downgrade to http if localhost
            if 'localhost' in url and url.startswith('https://'):
                http_url = url.replace('https://', 'http://')
                try:
                    resp = requests.post(http_url, json=payload, timeout=60)
                    body = resp.json()
                    if not resp.ok or body.get('error'):
                        return jsonify({ 'error': body.get('error') or f'Function error {resp.status_code}' }), 500
                    return jsonify(body)
                except Exception as ex2:  # pragma: no cover
                    return jsonify({'error': str(ex2)}), 500
            return jsonify({'error': str(ssl_ex)}), 500
        except Exception as ex:  # pragma: no cover
            return jsonify({'error': str(ex)}), 500

    return app

app = create_app()
